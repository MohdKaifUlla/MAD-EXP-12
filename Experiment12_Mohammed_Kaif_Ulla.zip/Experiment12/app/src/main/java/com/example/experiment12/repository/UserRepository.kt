
package com.example.experiment12.repository

import com.example.experiment12.api.ApiService
import com.example.experiment12.api.CreatePostRequest
import com.example.experiment12.api.CreatePostResponse
import com.example.experiment12.models.User
import retrofit2.Response

class UserRepository(
    private val apiService: ApiService
) {

    // Fetch user details using GET request
    suspend fun getUser(userId: Int): Response<User> {
        return apiService.getUser(userId)
    }

    // Create a post using POST request
    suspend fun createPost(
        title: String,
        body: String,
        userId: Int
    ): Response<CreatePostResponse> {

        val request = CreatePostRequest(
            title = title,
            body = body,
            userId = userId
        )

        return apiService.createPost(request)
    }
}
