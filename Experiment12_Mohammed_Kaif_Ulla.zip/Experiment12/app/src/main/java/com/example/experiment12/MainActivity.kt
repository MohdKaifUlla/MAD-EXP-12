package com.example.experiment12

import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.example.experiment12.api.RetrofitClient
import com.example.experiment12.repository.UserRepository
import com.google.gson.GsonBuilder
import kotlinx.coroutines.launch

class MainActivity : AppCompatActivity() {

    private lateinit var repository: UserRepository

    private lateinit var etUserId: EditText
    private lateinit var etPostTitle: EditText
    private lateinit var etPostBody: EditText

    private lateinit var btnGetUser: Button
    private lateinit var btnPostData: Button

    private lateinit var tvConnection: TextView
    private lateinit var tvGetCount: TextView
    private lateinit var tvPostCount: TextView

    private lateinit var tvUserName: TextView
    private lateinit var tvUserEmail: TextView
    private lateinit var tvUserPhone: TextView
    private lateinit var tvUserAddress: TextView

    private lateinit var tvResponseStatus: TextView
    private lateinit var tvResponseBody: TextView

    private lateinit var progressBar: ProgressBar

    private var getCount = 0
    private var postCount = 0

    private val gson = GsonBuilder()
        .setPrettyPrinting()
        .create()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        repository = UserRepository(RetrofitClient.apiService)

        initializeViews()
        setupListeners()
    }

    private fun initializeViews() {

        etUserId = findViewById(R.id.etUserId)
        etPostTitle = findViewById(R.id.etPostTitle)
        etPostBody = findViewById(R.id.etPostBody)

        btnGetUser = findViewById(R.id.btnGetUser)
        btnPostData = findViewById(R.id.btnPostData)

        tvConnection = findViewById(R.id.tvConnection)
        tvGetCount = findViewById(R.id.tvGetCount)
        tvPostCount = findViewById(R.id.tvPostCount)

        tvUserName = findViewById(R.id.tvUserName)
        tvUserEmail = findViewById(R.id.tvUserEmail)
        tvUserPhone = findViewById(R.id.tvUserPhone)
        tvUserAddress = findViewById(R.id.tvUserAddress)

        tvResponseStatus = findViewById(R.id.tvResponseStatus)
        tvResponseBody = findViewById(R.id.tvResponseBody)

        progressBar = findViewById(R.id.progressBar)
    }

    private fun setupListeners() {

        btnGetUser.setOnClickListener {
            fetchUser()
        }

        btnPostData.setOnClickListener {
            submitPost()
        }
    }

    // GET REQUEST

    private fun fetchUser() {

        val idText = etUserId.text.toString().trim()

        if (idText.isEmpty()) {
            etUserId.error = "Please enter a User ID"
            return
        }

        val userId = idText.toIntOrNull()

        if (userId == null || userId <= 0) {
            etUserId.error = "Enter a valid positive User ID"
            return
        }

        lifecycleScope.launch {

            setLoading(true)
            tvResponseStatus.text = "STATUS: SENDING GET REQUEST"
            tvResponseBody.text = "Connecting to server..."

            try {

                val response = repository.getUser(userId)

                getCount++
                tvGetCount.text = getCount.toString()

                if (response.isSuccessful && response.body() != null) {

                    val user = response.body()!!

                    tvConnection.text = "CONNECTED"

                    tvUserName.text = user.name
                    tvUserEmail.text = "✉  ${user.email}"
                    tvUserPhone.text = "☎  ${user.phone}"

                    tvUserAddress.text =
                        "⌖  ${user.address.street}, " +
                                "${user.address.city}, ${user.address.zipcode}"

                    tvResponseStatus.text =
                        "STATUS: ${response.code()} SUCCESS"

                    tvResponseBody.text =
                        gson.toJson(user)

                    Toast.makeText(
                        this@MainActivity,
                        "User details fetched successfully!",
                        Toast.LENGTH_SHORT
                    ).show()

                } else {

                    tvConnection.text = "CONNECTED"

                    tvUserName.text = "No user found"
                    tvUserEmail.text = "No email available"
                    tvUserPhone.text = "No phone available"
                    tvUserAddress.text = "No address available"

                    tvResponseStatus.text =
                        "STATUS: ${response.code()} ERROR"

                    tvResponseBody.text =
                        "The requested user was not found.\n" +
                                "Please check the User ID and try again."

                }

            } catch (e: Exception) {

                tvConnection.text = "OFFLINE"

                tvResponseStatus.text = "STATUS: NETWORK ERROR"
                tvResponseBody.text =
                    e.localizedMessage ?: "Unable to connect to server."

                Toast.makeText(
                    this@MainActivity,
                    "Network request failed",
                    Toast.LENGTH_SHORT
                ).show()

            } finally {
                setLoading(false)
            }
        }
    }

    // POST REQUEST

    private fun submitPost() {

        val title = etPostTitle.text.toString().trim()
        val body = etPostBody.text.toString().trim()

        if (title.isEmpty()) {
            etPostTitle.error = "Enter post title"
            return
        }

        if (body.isEmpty()) {
            etPostBody.error = "Enter post description"
            return
        }

        lifecycleScope.launch {

            setLoading(true)
            tvResponseStatus.text = "STATUS: SENDING POST REQUEST"
            tvResponseBody.text = "Submitting data to server..."

            try {

                val response = repository.createPost(
                    title = title,
                    body = body,
                    userId = 1
                )

                postCount++
                tvPostCount.text = postCount.toString()

                if (response.isSuccessful && response.body() != null) {

                    val result = response.body()!!

                    tvConnection.text = "CONNECTED"

                    tvResponseStatus.text =
                        "STATUS: ${response.code()} CREATED"

                    tvResponseBody.text =
                        gson.toJson(result)

                    Toast.makeText(
                        this@MainActivity,
                        "Post submitted successfully!",
                        Toast.LENGTH_SHORT
                    ).show()

                } else {

                    tvResponseStatus.text =
                        "STATUS: ${response.code()} ERROR"

                    tvResponseBody.text =
                        response.errorBody()?.string()
                            ?: "Unable to submit post."
                }

            } catch (e: Exception) {

                tvConnection.text = "OFFLINE"

                tvResponseStatus.text = "STATUS: NETWORK ERROR"

                tvResponseBody.text =
                    e.localizedMessage ?: "Unable to connect to server."

                Toast.makeText(
                    this@MainActivity,
                    "POST request failed",
                    Toast.LENGTH_SHORT
                ).show()

            } finally {
                setLoading(false)
            }
        }
    }

    // LOADING STATE

    private fun setLoading(isLoading: Boolean) {

        progressBar.visibility =
            if (isLoading) View.VISIBLE else View.GONE

        btnGetUser.isEnabled = !isLoading
        btnPostData.isEnabled = !isLoading

        btnGetUser.alpha = if (isLoading) 0.5f else 1f
        btnPostData.alpha = if (isLoading) 0.5f else 1f
    }
}
