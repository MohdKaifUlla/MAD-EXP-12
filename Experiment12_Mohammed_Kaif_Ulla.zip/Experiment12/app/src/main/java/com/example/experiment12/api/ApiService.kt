
package com.example.experiment12.api

import com.example.experiment12.models.User
import retrofit2.Response
import retrofit2.http.Body
import retrofit2.http.GET
import retrofit2.http.POST
import retrofit2.http.Path

data class CreatePostRequest(
    val title: String,
    val body: String,
    val userId: Int
)

data class CreatePostResponse(
    val id: Int,
    val title: String,
    val body: String,
    val userId: Int
)

interface ApiService {

    // GET Request: Fetch user details
    @GET("users/{id}")
    suspend fun getUser(
        @Path("id") userId: Int
    ): Response<User>

    // POST Request: Send data to server
    @POST("posts")
    suspend fun createPost(
        @Body post: CreatePostRequest
    ): Response<CreatePostResponse>
}
